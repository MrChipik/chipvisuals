package com.chipvisuals;

import com.chipvisuals.config.ConfigManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChipVisualsClient implements ClientModInitializer {
    public static final String MOD_ID = "chipvisuals";
    public static final Logger LOGGER = LoggerFactory.getLogger("CHIP VISUALS");

    private static KeyBinding settingsKey;

    @Override
    public void onInitializeClient() {
        ConfigManager.load();

        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chipvisuals.settings",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.chipvisuals"
        ));

        // Этап 1: проверка, что мод загружен. На этапе 3 здесь откроется экран настроек.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (settingsKey.wasPressed()) {
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("CHIP VISUALS загружен"), true);
                }
            }
        });

        LOGGER.info("CHIP VISUALS инициализирован");
    }
}
