package com.chipvisuals.config;

/** Все настройки мода. Сохраняются в config/chipvisuals.json. */
public class ChipConfig {
    // General
    public boolean customMainMenu = true;
    public boolean customMultiplayer = true;

    // Interface
    public boolean customInventory = true;

    // HUD
    public boolean hudEnabled = true;
    public boolean showFps = true;
    public boolean showCoords = true;
    public boolean showCps = true;
    public boolean showKeystrokes = true;
    public boolean showArmor = true;
    public boolean showEffects = true;

    // Fullbright
    public boolean fullbright = false;

    // Animations
    public boolean animations = true;
    public float animationSpeed = 1.0f; // 0.25 .. 2.0

    // Visuals
    public float glowIntensity = 0.6f; // 0 .. 1
}
