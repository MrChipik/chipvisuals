package com.chipvisuals.config;

import com.chipvisuals.ChipVisualsClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("chipvisuals.json");
    private static ChipConfig config = new ChipConfig();

    private ConfigManager() {}

    public static ChipConfig get() {
        return config;
    }

    public static void load() {
        if (Files.exists(FILE)) {
            try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
                ChipConfig loaded = GSON.fromJson(reader, ChipConfig.class);
                if (loaded != null) {
                    config = loaded;
                }
            } catch (Exception e) {
                ChipVisualsClient.LOGGER.error("Не удалось прочитать конфиг, используются значения по умолчанию", e);
            }
        }
        save(); // создаёт файл и дописывает новые поля после обновлений
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(config, writer);
            }
        } catch (IOException e) {
            ChipVisualsClient.LOGGER.error("Не удалось сохранить конфиг", e);
        }
    }
}
