package com.chipvisuals.ui;

/** Единая палитра Dark Emerald Glass / Soft Neon (цвета в формате ARGB). */
public final class Theme {
    private Theme() {}

    public static final int BG_DEEP        = 0xFF050A08; // почти чёрный
    public static final int BG_PANEL       = 0xCC0A1612; // стеклянная панель
    public static final int BG_PANEL_LIGHT = 0xCC10241D;
    public static final int EMERALD_DARK   = 0xFF0B3B2C;
    public static final int EMERALD        = 0xFF14A06C;
    public static final int EMERALD_SOFT   = 0xFF3DDC97; // мягкий неон
    public static final int BORDER         = 0x4D3DDC97;
    public static final int TEXT           = 0xFFE6F5EE;
    public static final int TEXT_DIM       = 0xFF7FA595;

    public static int withAlpha(int argb, float alpha) {
        int a = Math.max(0, Math.min(255, (int) (alpha * 255f)));
        return (a << 24) | (argb & 0x00FFFFFF);
    }

    public static int lerp(int from, int to, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = (int) (((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = (int) (((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = (int) ((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
