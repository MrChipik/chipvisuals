# CHIP VISUALS — этап 1 (Fabric 1.21.4, Java 21)

1. Скачай шаблон на https://fabricmc.net/develop/template (Minecraft 1.21.4, Java 21), чтобы получить gradlew и gradle/wrapper.
2. Скопируй из этого архива поверх шаблона: build.gradle, gradle.properties, settings.gradle, src/.
   Удали из шаблона его папку src/main/java/com/example и src/main/resources/assets/modid, если они остались.
3. Запуск клиента для теста: ./gradlew runClient
4. Сборка: ./gradlew build  -> build/libs/chipvisuals-0.1.0.jar (кладёшь в mods вместе с Fabric API 1.21.4)
